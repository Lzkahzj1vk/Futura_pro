import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, Plus, Check, CheckCheck } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface TopbarProps {
  title: string;
}

export default function Topbar({ title }: TopbarProps) {
  const { notifications, unreadCount, markNotifRead, markAllRead } = useApp();
  const [showNotifs, setShowNotifs] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setShowNotifs(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const timeAgo = (dateStr: string) => {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return "à l'instant";
    if (mins < 60) return `il y a ${mins} min`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `il y a ${hours}h`;
    const days = Math.floor(hours / 24);
    return `il y a ${days}j`;
  };

  const couleurMap: Record<string, string> = {
    blue: '#2563EB', green: '#059669', amber: '#D97706', red: '#DC2626', purple: '#7C3AED'
  };

  return (
    <header style={{
      height: 60, background: 'var(--white)', borderBottom: '1px solid var(--border)',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 24px', position: 'sticky', top: 0, zIndex: 30,
    }}>
      <h1 style={{ fontSize: 16, fontWeight: 600, color: 'var(--ink)', margin: 0 }}>
        {title}
      </h1>

      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        {/* Notification bell */}
        <div ref={ref} style={{ position: 'relative' }}>
          <button
            onClick={() => setShowNotifs(v => !v)}
            style={{
              position: 'relative', width: 36, height: 36, borderRadius: 10,
              border: '1px solid var(--border)', background: 'transparent',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer', color: 'var(--ink-soft)',
            }}
          >
            <Bell size={16} />
            {unreadCount > 0 && (
              <span style={{
                position: 'absolute', top: -4, right: -4,
                background: '#DC2626', color: 'white',
                borderRadius: '50%', width: 16, height: 16,
                fontSize: 10, fontWeight: 700,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                border: '2px solid white',
              }}>
                {unreadCount > 9 ? '9+' : unreadCount}
              </span>
            )}
          </button>

          {showNotifs && (
            <div style={{
              position: 'absolute', top: '100%', right: 0, marginTop: 8,
              background: 'var(--white)', border: '1px solid var(--border)',
              borderRadius: 14, boxShadow: '0 8px 24px rgba(0,0,0,.1)',
              width: 340, zIndex: 100, overflow: 'hidden',
            }}>
              <div style={{
                padding: '14px 16px', borderBottom: '1px solid var(--border)',
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              }}>
                <span style={{ fontWeight: 600, fontSize: 14 }}>Notifications</span>
                <button
                  onClick={markAllRead}
                  style={{
                    background: 'none', border: 'none', cursor: 'pointer',
                    fontSize: 11, color: 'var(--accent)', fontWeight: 500,
                    display: 'flex', alignItems: 'center', gap: 4,
                  }}
                >
                  <CheckCheck size={12} /> Tout marquer comme lu
                </button>
              </div>
              <div style={{ maxHeight: 320, overflowY: 'auto' }}>
                {notifications.slice(0, 10).map(n => (
                  <div
                    key={n.id}
                    onClick={() => markNotifRead(n.id)}
                    style={{
                      padding: '12px 16px',
                      borderBottom: '1px solid var(--border)',
                      background: n.lu ? 'transparent' : '#F0F7FF',
                      cursor: 'pointer',
                      display: 'flex', gap: 10, alignItems: 'flex-start',
                    }}
                  >
                    <div style={{
                      width: 8, height: 8, borderRadius: '50%', flexShrink: 0, marginTop: 5,
                      background: couleurMap[n.couleur] || '#6B7280',
                    }} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ink)' }}>{n.titre}</div>
                      <div style={{ fontSize: 12, color: 'var(--ink-soft)', marginTop: 2 }}>{n.description}</div>
                      <div style={{ fontSize: 11, color: 'var(--ink-faint)', marginTop: 4 }}>{timeAgo(n.createdAt)}</div>
                    </div>
                    {!n.lu && <Check size={12} style={{ color: 'var(--accent)', flexShrink: 0, marginTop: 4 }} />}
                  </div>
                ))}
                {notifications.length === 0 && (
                  <div style={{ padding: 32, textAlign: 'center', color: 'var(--ink-faint)', fontSize: 13 }}>
                    Aucune notification
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* New entry button */}
        <button
          onClick={() => navigate('/saisie')}
          className="btn-primary"
        >
          <Plus size={14} />
          Nouvelle saisie
        </button>
      </div>
    </header>
  );
}
