import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Save, ArrowLeft, AlertCircle } from 'lucide-react';
import Layout from '../components/Layout';
import { useApp } from '../context/AppContext';
import { TYPES_ACTIVITE } from '../data/mockData';
import { format } from 'date-fns';

export default function Saisie() {
  const { id } = useParams();
  const isEdit = Boolean(id);
  const navigate = useNavigate();
  const { saisies, projets, addSaisie, updateSaisie, addFlash } = useApp();

  const existing = isEdit ? saisies.find(s => s.id === Number(id)) : null;

  const todayStr = format(new Date(), 'yyyy-MM-dd');

  const [typeActivite, setTypeActivite] = useState(existing?.typeActivite || '');
  const [date, setDate] = useState(existing?.date || todayStr);
  const [heures, setHeures] = useState(existing?.heures?.toString() || '8');
  const [projetId, setProjetId] = useState<string>(existing?.projetId?.toString() || '');
  const [commentaire, setCommentaire] = useState(existing?.commentaire || '');
  const [congeType, setCongeType] = useState<'1jour' | 'multi'>('1jour');
  const [congeDateDebut, setCongeDateDebut] = useState(existing?.congeDateDebut || todayStr);
  const [congeDateFin, setCongeDateFin] = useState(existing?.congeDateFin || todayStr);
  const [congeHeures, setCongeHeures] = useState('8');
  const [error, setError] = useState('');

  const isConge = typeActivite === 'Congé';
  const activeProjets = projets.filter(p => p.statut === 'actif');

  useEffect(() => {
    if (existing?.typeActivite === 'Congé') {
      if (existing.congeDateDebut && existing.congeDateFin) {
        setCongeType('multi');
        setCongeDateDebut(existing.congeDateDebut);
        setCongeDateFin(existing.congeDateFin);
      } else {
        setCongeType('1jour');
        setCongeHeures(existing.heures.toString());
      }
    }
  }, [existing]);

  const isWeekend = (dateStr: string) => {
    const d = new Date(dateStr);
    return d.getDay() === 0 || d.getDay() === 6;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (isConge) {
      if (congeType === '1jour') {
        if (isWeekend(date)) {
          setError('La date saisie ne peut pas tomber un samedi ou un dimanche.');
          return;
        }
        const saisieData = {
          userId: 1,
          projetId: null,
          date,
          typeActivite: 'Congé',
          heures: parseFloat(congeHeures),
          commentaire,
          statut: 'en_attente' as const,
          congeDateDebut: null,
          congeDateFin: null,
        };
        if (isEdit && existing) {
          updateSaisie(existing.id, saisieData);
          addFlash('success', 'Saisie modifiée avec succès!');
        } else {
          addSaisie(saisieData);
          addFlash('success', 'Saisie enregistrée avec succès!');
        }
      } else {
        if (isWeekend(congeDateDebut) || isWeekend(congeDateFin)) {
          setError('Les dates de congé ne peuvent pas tomber un samedi ou un dimanche.');
          return;
        }
        const d1 = new Date(congeDateDebut);
        const d2 = new Date(congeDateFin);
        const nbJours = Math.floor((d2.getTime() - d1.getTime()) / 86400000) + 1;
        const saisieData = {
          userId: 1,
          projetId: null,
          date: congeDateDebut,
          typeActivite: 'Congé',
          heures: nbJours * 8,
          commentaire,
          statut: 'en_attente' as const,
          congeDateDebut,
          congeDateFin,
        };
        if (isEdit && existing) {
          updateSaisie(existing.id, saisieData);
          addFlash('success', 'Saisie modifiée avec succès!');
        } else {
          addSaisie(saisieData);
          addFlash('success', 'Saisie enregistrée avec succès!');
        }
      }
    } else {
      if (isWeekend(date)) {
        setError('La date saisie ne peut pas tomber un samedi ou un dimanche.');
        return;
      }
      if (!typeActivite) {
        setError("Veuillez sélectionner un type d'activité.");
        return;
      }
      const saisieData = {
        userId: 1,
        projetId: projetId ? parseInt(projetId) : null,
        date,
        typeActivite,
        heures: parseFloat(heures),
        commentaire,
        statut: 'en_attente' as const,
        congeDateDebut: null,
        congeDateFin: null,
      };
      if (isEdit && existing) {
        updateSaisie(existing.id, saisieData);
        addFlash('success', 'Saisie modifiée avec succès!');
      } else {
        addSaisie(saisieData);
        addFlash('success', 'Saisie enregistrée avec succès!');
      }
    }
    navigate('/historique');
  };

  const groupedActivites = [
    { groupe: 'Plans & Schémas', items: TYPES_ACTIVITE.filter(t => t.badge === 'badge-blue' && t.value !== 'Congé') },
    { groupe: 'Notes de Calcul', items: TYPES_ACTIVITE.filter(t => t.badge === 'badge-purple') },
    { groupe: 'Bilans', items: TYPES_ACTIVITE.filter(t => t.badge === 'badge-amber' && !['Eclairage', 'Photovoltaïque', "Gestion d'éclairage", 'Congé'].includes(t.value)) },
    { groupe: 'Réseaux & Systèmes', items: TYPES_ACTIVITE.filter(t => t.badge === 'badge-gray') },
    { groupe: 'Autres', items: TYPES_ACTIVITE.filter(t => ['Eclairage', 'Photovoltaïque', "Gestion d'éclairage", 'Congé'].includes(t.value)) },
  ];

  return (
    <Layout title={isEdit ? 'Modifier la saisie' : 'Nouvelle saisie'}>
      <div style={{ maxWidth: 720, margin: '0 auto' }}>
        {/* Back */}
        <button
          onClick={() => navigate(-1)}
          style={{
            display: 'flex', alignItems: 'center', gap: 6, marginBottom: 20,
            background: 'none', border: 'none', cursor: 'pointer',
            color: 'var(--ink-soft)', fontSize: 13,
          }}
        >
          <ArrowLeft size={14} /> Retour
        </button>

        <div className="card">
          <div style={{ marginBottom: 24 }}>
            <h2 style={{ fontSize: 18, fontWeight: 700, margin: '0 0 4px', color: 'var(--ink)' }}>
              {isEdit ? 'Modifier la saisie' : 'Nouvelle saisie d\'activité'}
            </h2>
            <p style={{ fontSize: 13, color: 'var(--ink-soft)', margin: 0 }}>
              Renseignez les informations de votre activité du jour
            </p>
          </div>

          {error && (
            <div style={{
              display: 'flex', alignItems: 'center', gap: 8,
              background: '#FEF2F2', border: '1px solid #FECACA',
              borderRadius: 10, padding: '10px 14px', marginBottom: 20,
              color: '#991B1B', fontSize: 13,
            }}>
              <AlertCircle size={15} />
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            {/* Type activité */}
            <div>
              <label className="form-label">Type d'activité *</label>
              <select
                value={typeActivite}
                onChange={e => setTypeActivite(e.target.value)}
                required
                className="form-input"
              >
                <option value="">— Sélectionner —</option>
                {groupedActivites.map(g => (
                  <optgroup key={g.groupe} label={g.groupe}>
                    {g.items.map(t => (
                      <option key={t.value} value={t.value}>{t.label}</option>
                    ))}
                  </optgroup>
                ))}
              </select>
            </div>

            {/* Congé specific fields */}
            {isConge ? (
              <div style={{ background: '#FFFBEB', border: '1px solid #FDE68A', borderRadius: 12, padding: 16 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: '#92400E', marginBottom: 12 }}>
                  🌴 Configuration du congé
                </div>

                {/* Durée type */}
                <div style={{ marginBottom: 14 }}>
                  <label className="form-label">Durée</label>
                  <div style={{ display: 'flex', gap: 10 }}>
                    <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, cursor: 'pointer', padding: '8px 14px', borderRadius: 8, background: congeType === '1jour' ? '#D97706' : 'white', color: congeType === '1jour' ? 'white' : 'var(--ink)', border: '1px solid #FDE68A', transition: 'all 0.2s' }}>
                      <input type="radio" name="congeType" value="1jour" checked={congeType === '1jour'} onChange={() => setCongeType('1jour')} style={{ display: 'none' }} />
                      ≤ 1 jour
                    </label>
                    <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, cursor: 'pointer', padding: '8px 14px', borderRadius: 8, background: congeType === 'multi' ? '#D97706' : 'white', color: congeType === 'multi' ? 'white' : 'var(--ink)', border: '1px solid #FDE68A', transition: 'all 0.2s' }}>
                      <input type="radio" name="congeType" value="multi" checked={congeType === 'multi'} onChange={() => setCongeType('multi')} style={{ display: 'none' }} />
                      Plusieurs jours
                    </label>
                  </div>
                </div>

                {congeType === '1jour' ? (
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
                    <div>
                      <label className="form-label">Date</label>
                      <input type="date" value={date} onChange={e => setDate(e.target.value)} className="form-input" required />
                    </div>
                    <div>
                      <label className="form-label">Heures</label>
                      <select value={congeHeures} onChange={e => setCongeHeures(e.target.value)} className="form-input">
                        <option value="4">Demi-journée (4h)</option>
                        <option value="8">Journée complète (8h)</option>
                      </select>
                    </div>
                  </div>
                ) : (
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
                    <div>
                      <label className="form-label">Date de début</label>
                      <input type="date" value={congeDateDebut} onChange={e => setCongeDateDebut(e.target.value)} className="form-input" required />
                    </div>
                    <div>
                      <label className="form-label">Date de fin</label>
                      <input type="date" value={congeDateFin} min={congeDateDebut} onChange={e => setCongeDateFin(e.target.value)} className="form-input" required />
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                {/* Date */}
                <div>
                  <label className="form-label">Date *</label>
                  <input
                    type="date"
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    required
                    className="form-input"
                  />
                </div>
                {/* Heures */}
                <div>
                  <label className="form-label">Nombre d'heures *</label>
                  <input
                    type="number"
                    value={heures}
                    onChange={e => setHeures(e.target.value)}
                    min="0.5" max="24" step="0.5"
                    required
                    className="form-input"
                  />
                </div>
              </div>
            )}

            {/* Projet */}
            {!isConge && (
              <div>
                <label className="form-label">Projet (optionnel)</label>
                <select
                  value={projetId}
                  onChange={e => setProjetId(e.target.value)}
                  className="form-input"
                >
                  <option value="">Interne (sans projet)</option>
                  {activeProjets.map(p => (
                    <option key={p.id} value={p.id.toString()}>
                      {p.client ? `${p.client} — ${p.nom}` : p.nom}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Commentaire */}
            <div>
              <label className="form-label">Commentaire (optionnel)</label>
              <textarea
                value={commentaire}
                onChange={e => setCommentaire(e.target.value)}
                placeholder="Décrivez votre activité..."
                rows={3}
                className="form-input"
                style={{ resize: 'vertical' }}
              />
            </div>

            {/* Actions */}
            <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end', paddingTop: 8, borderTop: '1px solid var(--border)' }}>
              <button type="button" onClick={() => navigate(-1)} className="btn-secondary">
                Annuler
              </button>
              <button type="submit" className="btn-primary">
                <Save size={14} />
                {isEdit ? 'Enregistrer les modifications' : 'Enregistrer la saisie'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </Layout>
  );
}
