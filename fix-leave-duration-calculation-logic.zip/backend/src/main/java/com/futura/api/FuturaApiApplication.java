package com.futura.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FuturaApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(FuturaApiApplication.class, args);
    }
}
