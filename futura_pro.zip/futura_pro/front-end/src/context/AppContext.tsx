import { createContext, useContext, useState, ReactNode } from 'react';
import { User, Saisie, Conge, Notification, Projet } from '../types';
import {
  mockUser, mockSaisies, mockConges, mockNotifications, mockProjets
} from '../data/mockData';

interface AppContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => boolean;
  logout: () => void;
  saisies: Saisie[];
  addSaisie: (s: Omit<Saisie, 'id' | 'createdAt'>) => void;
  updateSaisie: (id: number, s: Partial<Saisie>) => void;
  deleteSaisie: (id: number) => void;
  conges: Conge[];
  addConge: (c: Omit<Conge, 'id' | 'createdAt'>) => void;
  projets: Projet[];
  notifications: Notification[];
  markNotifRead: (id: number) => void;
  markAllRead: () => void;
  unreadCount: number;
  flashMessages: { type: string; message: string }[];
  addFlash: (type: string, message: string) => void;
  clearFlash: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [saisies, setSaisies] = useState<Saisie[]>(mockSaisies);
  const [conges, setConges] = useState<Conge[]>(mockConges);
  const [projets] = useState<Projet[]>(mockProjets);
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications);
  const [flashMessages, setFlashMessages] = useState<{ type: string; message: string }[]>([]);

  const login = (email: string, password: string): boolean => {
    if (email === 'jean.dupont@futura-expertise.fr' && password === 'password') {
      setUser(mockUser);
      setIsAuthenticated(true);
      return true;
    }
    if (email && password.length >= 4) {
      setUser({ ...mockUser, email, prenom: email.split('@')[0].split('.')[0] || 'User' });
      setIsAuthenticated(true);
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
  };

  const addSaisie = (s: Omit<Saisie, 'id' | 'createdAt'>) => {
    const newSaisie: Saisie = {
      ...s,
      id: Date.now(),
      createdAt: new Date().toISOString(),
    };
    setSaisies(prev => [newSaisie, ...prev]);
    const notif: Notification = {
      id: Date.now() + 1,
      userId: 1,
      titre: 'Saisie enregistrée',
      description: s.typeActivite === 'Congé'
        ? `Congé de ${s.heures} jour(s) ajouté.`
        : `Saisie "${s.typeActivite}" de ${s.heures}h ajoutée.`,
      couleur: 'green',
      lu: false,
      createdAt: new Date().toISOString(),
    };
    setNotifications(prev => [notif, ...prev]);
  };

  const updateSaisie = (id: number, data: Partial<Saisie>) => {
    setSaisies(prev => prev.map(s => s.id === id ? { ...s, ...data } : s));
  };

  const deleteSaisie = (id: number) => {
    setSaisies(prev => prev.filter(s => s.id !== id));
  };

  const addConge = (c: Omit<Conge, 'id' | 'createdAt'>) => {
    const newConge: Conge = {
      ...c,
      id: Date.now(),
      createdAt: new Date().toISOString(),
    };
    setConges(prev => [newConge, ...prev]);
    const notif: Notification = {
      id: Date.now() + 1,
      userId: 1,
      titre: 'Demande de congé envoyée',
      description: `Demande de ${c.nbJours} jour(s) soumise, en attente d'approbation.`,
      couleur: 'amber',
      lu: false,
      createdAt: new Date().toISOString(),
    };
    setNotifications(prev => [notif, ...prev]);
  };

  const markNotifRead = (id: number) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, lu: true } : n));
  };

  const markAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, lu: true })));
  };

  const unreadCount = notifications.filter(n => !n.lu).length;

  const addFlash = (type: string, message: string) => {
    setFlashMessages([{ type, message }]);
    setTimeout(() => setFlashMessages([]), 4000);
  };

  const clearFlash = () => setFlashMessages([]);

  return (
    <AppContext.Provider value={{
      user, isAuthenticated, login, logout,
      saisies, addSaisie, updateSaisie, deleteSaisie,
      conges, addConge,
      projets, notifications, markNotifRead, markAllRead, unreadCount,
      flashMessages, addFlash, clearFlash,
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
};
