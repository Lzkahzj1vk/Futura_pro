export interface User {
  id: number;
  nom: string;
  prenom: string;
  email: string;
  role: 'admin' | 'consultant' | 'manager';
  createdAt: string;
}

export interface Projet {
  id: number;
  nom: string;
  client: string;
  statut: 'actif' | 'inactif' | 'archive';
  createdAt: string;
}

export interface Saisie {
  id: number;
  userId: number;
  projetId: number | null;
  date: string;
  typeActivite: string;
  heures: number;
  commentaire: string;
  statut: 'en_attente' | 'valide' | 'rejete' | 'approuve' | 'refuse';
  congeDateDebut?: string | null;
  congeDateFin?: string | null;
  createdAt: string;
}

export interface Conge {
  id: number;
  userId: number;
  typeConge: string;
  dateDebut: string;
  dateFin: string;
  nbJours: number;
  motif: string;
  statut: 'en_attente' | 'approuve' | 'refuse';
  createdAt: string;
}

export interface Notification {
  id: number;
  userId: number;
  titre: string;
  description: string;
  couleur: 'blue' | 'green' | 'amber' | 'red' | 'purple';
  lu: boolean;
  createdAt: string;
}
