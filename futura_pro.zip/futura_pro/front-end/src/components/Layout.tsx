import { ReactNode } from 'react';
import Sidebar from './Sidebar';
import Topbar from './Topbar';
import FlashMessage from './FlashMessage';

interface LayoutProps {
  children: ReactNode;
  title: string;
}

export default function Layout({ children, title }: LayoutProps) {
  return (
    <div className="layout">
      <Sidebar />
      <div className="main-content">
        <Topbar title={title} />
        <FlashMessage />
        <main style={{ padding: '24px', flex: 1 }}>
          {children}
        </main>
      </div>
    </div>
  );
}
