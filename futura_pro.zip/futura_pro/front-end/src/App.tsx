import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider, useApp } from './context/AppContext';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Saisie from './pages/Saisie';
import Historique from './pages/Historique';
import Rapports from './pages/Rapports';
import Conge from './pages/Conge';

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useApp();
  return isAuthenticated ? <>{children}</> : <Navigate to="/login" replace />;
}

function AppRoutes() {
  const { isAuthenticated } = useApp();

  return (
    <Routes>
      <Route path="/login" element={
        isAuthenticated ? <Navigate to="/dashboard" replace /> : <Login />
      } />
      <Route path="/dashboard" element={
        <ProtectedRoute><Dashboard /></ProtectedRoute>
      } />
      <Route path="/saisie" element={
        <ProtectedRoute><Saisie /></ProtectedRoute>
      } />
      <Route path="/saisie/:id/edit" element={
        <ProtectedRoute><Saisie /></ProtectedRoute>
      } />
      <Route path="/historique" element={
        <ProtectedRoute><Historique /></ProtectedRoute>
      } />
      <Route path="/rapports" element={
        <ProtectedRoute><Rapports /></ProtectedRoute>
      } />
      <Route path="/conge" element={
        <ProtectedRoute><Conge /></ProtectedRoute>
      } />
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppProvider>
        <AppRoutes />
      </AppProvider>
    </BrowserRouter>
  );
}
