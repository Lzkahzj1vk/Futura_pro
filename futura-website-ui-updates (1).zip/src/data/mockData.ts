import { User, Projet, Saisie, Conge, Notification } from '../types';

export const TYPES_ACTIVITE = [
  // Plans & Schémas
  { value: 'Liste des plans', label: 'Liste des plans', badge: 'badge-blue' },
  { value: 'Schémas des tableaux', label: 'Schémas des tableaux', badge: 'badge-blue' },
  { value: 'Plans des locaux techniques', label: 'Plans des locaux techniques', badge: 'badge-blue' },
  { value: 'Plans CDC', label: 'Plans CDC', badge: 'badge-blue' },
  { value: 'Plans des locaux types', label: 'Plans des locaux types', badge: 'badge-blue' },
  // Notes de Calcul
  { value: "Note de Calcul d'Eclairement", label: "Note de Calcul d'Eclairement", badge: 'badge-purple' },
  { value: 'Note de Calcul BT', label: 'Note de Calcul BT', badge: 'badge-purple' },
  { value: 'Note de Calcul MT', label: 'Note de Calcul MT', badge: 'badge-purple' },
  { value: 'Note de Calcul DC', label: 'Note de Calcul DC', badge: 'badge-purple' },
  { value: 'Note de Calcul Batterie', label: 'Note de Calcul Batterie', badge: 'badge-purple' },
  { value: 'Note de Calcul CDC', label: 'Note de Calcul CDC', badge: 'badge-purple' },
  { value: 'Note de Calcul de mise à la terre', label: 'Note de Calcul de mise à la terre', badge: 'badge-purple' },
  { value: 'Note de Calcul paratonnerre', label: 'Note de Calcul paratonnerre', badge: 'badge-purple' },
  // Bilans
  { value: 'Bilan de puissance', label: 'Bilan de puissance', badge: 'badge-amber' },
  { value: 'Bilan Thermique', label: 'Bilan Thermique', badge: 'badge-amber' },
  // Réseaux & Synoptiques
  { value: 'Synoptiques CFO', label: 'Synoptiques CFO', badge: 'badge-gray' },
  { value: 'Synoptiques CFA', label: 'Synoptiques CFA', badge: 'badge-gray' },
  { value: 'Réseau sous dallage', label: 'Réseau sous dallage', badge: 'badge-gray' },
  { value: 'Réseau extérieur', label: 'Réseau extérieur', badge: 'badge-gray' },
  { value: 'Réseau wifi', label: 'Réseau wifi', badge: 'badge-gray' },
  { value: 'Précâblage informatique', label: 'Précâblage informatique', badge: 'badge-gray' },
  // Carnets
  { value: 'Carnet des câbles CFO', label: 'Carnet des câbles CFO', badge: 'badge-gray' },
  { value: 'Carnet des câbles CFA', label: 'Carnet des câbles CFA', badge: 'badge-gray' },
  // Autres
  { value: 'Prises de courant et forces', label: 'Prises de courant et forces', badge: 'badge-blue' },
  { value: 'Eclairage', label: 'Eclairage', badge: 'badge-amber' },
  { value: 'Réservations', label: 'Réservations', badge: 'badge-gray' },
  { value: 'Mise à la terre et protection foudre', label: 'Mise à la terre et protection foudre', badge: 'badge-gray' },
  { value: 'Photovoltaïque', label: 'Photovoltaïque', badge: 'badge-amber' },
  { value: 'Sonorisation', label: 'Sonorisation', badge: 'badge-purple' },
  { value: 'Audiovisuel', label: 'Audiovisuel', badge: 'badge-purple' },
  { value: 'Système sécurité incendie', label: 'Système sécurité incendie', badge: 'badge-gray' },
  { value: 'Vidéosurveillance', label: 'Vidéosurveillance', badge: 'badge-gray' },
  { value: "Contrôle d'accès et d'intrusion", label: "Contrôle d'accès et d'intrusion", badge: 'badge-gray' },
  { value: "Gestion d'éclairage", label: "Gestion d'éclairage", badge: 'badge-amber' },
  { value: 'Aménagement local PCS', label: 'Aménagement local PCS', badge: 'badge-blue' },
  { value: 'Gestion domotique', label: 'Gestion domotique', badge: 'badge-purple' },
  { value: 'GTC', label: 'GTC', badge: 'badge-purple' },
  { value: 'TBE', label: 'TBE', badge: 'badge-blue' },
  { value: 'Congé', label: 'Congé', badge: 'badge-amber' },
];

export const TYPES_CONGE = [
  'Congé annuel',
  'Congé maladie',
  'Congé sans solde',
  'RTT',
  'Congé exceptionnel',
  'Télétravail',
];

export const BADGE_MAP: Record<string, string> = {
  'Liste des plans': 'badge-blue',
  'Schémas des tableaux': 'badge-blue',
  'Plans des locaux techniques': 'badge-blue',
  'Plans CDC': 'badge-blue',
  'Plans des locaux types': 'badge-blue',
  "Note de Calcul d'Eclairement": 'badge-purple',
  'Note de Calcul BT': 'badge-purple',
  'Note de Calcul MT': 'badge-purple',
  'Note de Calcul DC': 'badge-purple',
  'Note de Calcul Batterie': 'badge-purple',
  'Note de Calcul CDC': 'badge-purple',
  'Note de Calcul de mise à la terre': 'badge-purple',
  'Note de Calcul paratonnerre': 'badge-purple',
  'Bilan de puissance': 'badge-amber',
  'Bilan Thermique': 'badge-amber',
  'Synoptiques CFO': 'badge-gray',
  'Synoptiques CFA': 'badge-gray',
  'Réseau sous dallage': 'badge-gray',
  'Réseau extérieur': 'badge-gray',
  'Réseau wifi': 'badge-gray',
  'Précâblage informatique': 'badge-gray',
  'Carnet des câbles CFO': 'badge-gray',
  'Carnet des câbles CFA': 'badge-gray',
  'Prises de courant et forces': 'badge-blue',
  'Eclairage': 'badge-amber',
  'Réservations': 'badge-gray',
  'Mise à la terre et protection foudre': 'badge-gray',
  'Photovoltaïque': 'badge-amber',
  'Sonorisation': 'badge-purple',
  'Audiovisuel': 'badge-purple',
  'Système sécurité incendie': 'badge-gray',
  'Vidéosurveillance': 'badge-gray',
  "Contrôle d'accès et d'intrusion": 'badge-gray',
  "Gestion d'éclairage": 'badge-amber',
  'Aménagement local PCS': 'badge-blue',
  'Gestion domotique': 'badge-purple',
  'GTC': 'badge-purple',
  'TBE': 'badge-blue',
  'Congé': 'badge-amber',
};

export const mockUser: User = {
  id: 1,
  nom: 'Dupont',
  prenom: 'Jean',
  email: 'jean.dupont@futura-expertise.fr',
  role: 'consultant',
  createdAt: '2024-01-15T08:00:00Z',
};

export const mockProjets: Projet[] = [
  { id: 1, nom: 'Tour Montparnasse CFO', client: 'Bouygues Immobilier', statut: 'actif', createdAt: '2024-01-10T08:00:00Z' },
  { id: 2, nom: 'Rénovation réseau BT', client: 'EDF', statut: 'actif', createdAt: '2024-02-01T08:00:00Z' },
  { id: 3, nom: 'Centre Commercial Nord', client: 'Unibail', statut: 'actif', createdAt: '2024-02-15T08:00:00Z' },
  { id: 4, nom: 'Hôpital Saint-Louis Extension', client: 'AP-HP', statut: 'actif', createdAt: '2024-03-01T08:00:00Z' },
  { id: 5, nom: 'Campus Universitaire', client: 'Université Paris-Saclay', statut: 'actif', createdAt: '2024-03-10T08:00:00Z' },
  { id: 6, nom: 'Immeuble de bureaux La Défense', client: 'Gecina', statut: 'archive', createdAt: '2023-06-01T08:00:00Z' },
];

export const mockSaisies: Saisie[] = [
  {
    id: 1, userId: 1, projetId: 1,
    date: '2025-01-20', typeActivite: 'Plans des locaux techniques',
    heures: 7, commentaire: 'Finalisation des plans locaux TGBT',
    statut: 'valide', createdAt: '2025-01-20T09:00:00Z'
  },
  {
    id: 2, userId: 1, projetId: 2,
    date: '2025-01-21', typeActivite: 'Note de Calcul BT',
    heures: 5.5, commentaire: 'Note de calcul section 2',
    statut: 'en_attente', createdAt: '2025-01-21T09:00:00Z'
  },
  {
    id: 3, userId: 1, projetId: 3,
    date: '2025-01-22', typeActivite: 'Bilan de puissance',
    heures: 8, commentaire: 'Bilan complet avec tableau récap',
    statut: 'valide', createdAt: '2025-01-22T09:00:00Z'
  },
  {
    id: 4, userId: 1, projetId: null,
    date: '2025-01-23', typeActivite: 'Congé',
    heures: 8, commentaire: 'RTT',
    statut: 'approuve',
    congeDateDebut: null, congeDateFin: null,
    createdAt: '2025-01-23T09:00:00Z'
  },
  {
    id: 5, userId: 1, projetId: 4,
    date: '2025-01-24', typeActivite: 'Synoptiques CFO',
    heures: 6, commentaire: 'Synoptique distribution MT/BT',
    statut: 'en_attente', createdAt: '2025-01-24T09:00:00Z'
  },
  {
    id: 6, userId: 1, projetId: 1,
    date: '2025-01-27', typeActivite: 'Schémas des tableaux',
    heures: 7.5, commentaire: 'Schéma TGBT niveau R+2',
    statut: 'en_attente', createdAt: '2025-01-27T09:00:00Z'
  },
  {
    id: 7, userId: 1, projetId: 5,
    date: '2025-01-28', typeActivite: 'Eclairage',
    heures: 4, commentaire: 'Calcul flux lumineux salles de cours',
    statut: 'valide', createdAt: '2025-01-28T09:00:00Z'
  },
  {
    id: 8, userId: 1, projetId: null,
    date: '2025-01-29', typeActivite: 'Congé',
    heures: 16, commentaire: 'Congé annuel',
    statut: 'approuve',
    congeDateDebut: '2025-01-29', congeDateFin: '2025-01-30',
    createdAt: '2025-01-29T09:00:00Z'
  },
  {
    id: 9, userId: 1, projetId: 2,
    date: '2025-01-31', typeActivite: 'Vidéosurveillance',
    heures: 5, commentaire: 'Plan implantation caméras',
    statut: 'en_attente', createdAt: '2025-01-31T09:00:00Z'
  },
  {
    id: 10, userId: 1, projetId: 3,
    date: '2025-02-03', typeActivite: 'GTC',
    heures: 8, commentaire: 'Architecture GTC bâtiment principal',
    statut: 'valide', createdAt: '2025-02-03T09:00:00Z'
  },
  {
    id: 11, userId: 1, projetId: 4,
    date: '2025-02-04', typeActivite: 'Note de Calcul MT',
    heures: 6, commentaire: 'Calcul protections MT 20kV',
    statut: 'en_attente', createdAt: '2025-02-04T09:00:00Z'
  },
  {
    id: 12, userId: 1, projetId: 1,
    date: '2025-02-05', typeActivite: 'Réseau wifi',
    heures: 7, commentaire: 'Couverture wifi zones communes',
    statut: 'valide', createdAt: '2025-02-05T09:00:00Z'
  },
];

export const mockConges: Conge[] = [
  {
    id: 1, userId: 1, typeConge: 'Congé annuel',
    dateDebut: '2025-01-29', dateFin: '2025-01-30',
    nbJours: 2, motif: 'Vacances hiver',
    statut: 'approuve', createdAt: '2025-01-20T10:00:00Z'
  },
  {
    id: 2, userId: 1, typeConge: 'RTT',
    dateDebut: '2025-02-14', dateFin: '2025-02-14',
    nbJours: 1, motif: 'RTT mensuel',
    statut: 'en_attente', createdAt: '2025-02-01T10:00:00Z'
  },
  {
    id: 3, userId: 1, typeConge: 'Congé maladie',
    dateDebut: '2024-12-02', dateFin: '2024-12-04',
    nbJours: 3, motif: 'Grippe',
    statut: 'approuve', createdAt: '2024-12-02T08:00:00Z'
  },
  {
    id: 4, userId: 1, typeConge: 'Congé annuel',
    dateDebut: '2024-08-05', dateFin: '2024-08-16',
    nbJours: 10, motif: 'Vacances été',
    statut: 'approuve', createdAt: '2024-07-15T10:00:00Z'
  },
];

export const mockNotifications: Notification[] = [
  {
    id: 1, userId: 1, titre: 'Saisie validée',
    description: 'Votre saisie "Plans des locaux techniques" du 20/01 a été validée.',
    couleur: 'green', lu: false, createdAt: '2025-01-21T10:00:00Z'
  },
  {
    id: 2, userId: 1, titre: 'Demande de congé approuvée',
    description: 'Votre demande de congé du 29/01 au 30/01 a été approuvée.',
    couleur: 'green', lu: false, createdAt: '2025-01-22T09:00:00Z'
  },
  {
    id: 3, userId: 1, titre: 'Rappel de saisie',
    description: "N'oubliez pas de saisir vos heures de la semaine.",
    couleur: 'amber', lu: true, createdAt: '2025-01-20T08:00:00Z'
  },
  {
    id: 4, userId: 1, titre: 'Nouveau projet assigné',
    description: 'Vous avez été assigné au projet Campus Universitaire.',
    couleur: 'blue', lu: true, createdAt: '2025-01-15T08:00:00Z'
  },
];
