'use client';

import { useApp } from '../context/AppContext';
import { X } from 'lucide-react';

export default function FlashMessage() {
  const { flashMessages, clearFlash } = useApp();

  if (flashMessages.length === 0) return null;

  return (
    <div style={{ padding: '12px 24px 0' }}>
      {flashMessages.map((msg, i) => (
        <div
          key={i}
          className={`flash-${msg.type}`}
          style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '10px 16px', borderRadius: 10, fontSize: 13, fontWeight: 500,
          }}
        >
          <span>{msg.message}</span>
          <button
            onClick={clearFlash}
            style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', opacity: 0.7 }}
          >
            <X size={14} />
          </button>
        </div>
      ))}
    </div>
  );
}
