import { useState, useMemo } from 'react';
import { FileText, Download, BarChart3, PieChart, TrendingUp } from 'lucide-react';
import Layout from '../components/Layout';
import { useApp } from '../context/AppContext';
import { BADGE_MAP } from '../data/mockData';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart as RechartsPie, Pie, Cell, Legend } from 'recharts';
import { format, startOfMonth, endOfMonth, eachMonthOfInterval, subMonths } from 'date-fns';
import { fr } from 'date-fns/locale';

const COLORS = ['#2563EB', '#7C3AED', '#059669', '#D97706', '#DC2626', '#0891B2', '#DB2777', '#65A30D'];

const STATUT_LABEL: Record<string, string> = {
  en_attente: 'En attente', valide: 'Validé', rejete: 'Rejeté', approuve: 'Approuvé', refuse: 'Refusé',
};

export default function Rapports() {
  const { saisies, conges, projets } = useApp();

  const [filterType, setFilterType] = useState('');
  const [filterProjet, setFilterProjet] = useState('');
  const [filterDateDebut, setFilterDateDebut] = useState('');
  const [filterDateFin, setFilterDateFin] = useState('');

  const filteredSaisies = useMemo(() => {
    return saisies.filter(s => {
      if (filterType && s.typeActivite !== filterType) return false;
      if (filterProjet && s.projetId?.toString() !== filterProjet) return false;
      if (filterDateDebut && s.date < filterDateDebut) return false;
      if (filterDateFin && s.date > filterDateFin) return false;
      return true;
    });
  }, [saisies, filterType, filterProjet, filterDateDebut, filterDateFin]);

  const filteredConges = useMemo(() => {
    return conges.filter(c => {
      if (filterDateDebut && c.dateDebut < filterDateDebut) return false;
      if (filterDateFin && c.dateFin > filterDateFin) return false;
      return true;
    });
  }, [conges, filterDateDebut, filterDateFin]);

  const totalHeures = filteredSaisies.reduce((acc, s) => acc + s.heures, 0);
  const totalJours = filteredConges.reduce((acc, c) => acc + c.nbJours, 0);

  // Chart 1: Heures par mois (last 6 months)
  const monthlyData = useMemo(() => {
    const now = new Date();
    const months = eachMonthOfInterval({ start: subMonths(now, 5), end: now });
    return months.map(m => {
      const start = format(startOfMonth(m), 'yyyy-MM-dd');
      const end = format(endOfMonth(m), 'yyyy-MM-dd');
      const h = saisies
        .filter(s => s.date >= start && s.date <= end && s.typeActivite !== 'Congé')
        .reduce((acc, s) => acc + s.heures, 0);
      return { mois: format(m, 'MMM', { locale: fr }), heures: h };
    });
  }, [saisies]);

  // Chart 2: Répartition par type
  const typeData = useMemo(() => {
    const map: Record<string, number> = {};
    filteredSaisies.filter(s => s.typeActivite !== 'Congé').forEach(s => {
      map[s.typeActivite] = (map[s.typeActivite] || 0) + s.heures;
    });
    return Object.entries(map)
      .map(([name, value]) => ({ name: name.length > 20 ? name.slice(0, 20) + '…' : name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 8);
  }, [filteredSaisies]);

  // Chart 3: Heures par projet
  const projetData = useMemo(() => {
    const map: Record<number, { nom: string; heures: number }> = {};
    filteredSaisies.filter(s => s.projetId).forEach(s => {
      if (!map[s.projetId!]) {
        const p = projets.find(x => x.id === s.projetId);
        map[s.projetId!] = { nom: p ? (p.client ? `${p.client}` : p.nom) : 'Projet', heures: 0 };
      }
      map[s.projetId!].heures += s.heures;
    });
    return Object.values(map).sort((a, b) => b.heures - a.heures).slice(0, 6);
  }, [filteredSaisies, projets]);

  const getProjetDisplay = (projetId: number | null) => {
    if (!projetId) return 'Interne';
    const p = projets.find(x => x.id === projetId);
    if (!p) return 'Interne';
    return p.client ? `${p.client} — ${p.nom}` : p.nom;
  };

  const exportCSV = (type: 'saisies' | 'conges' | 'complet') => {
    let csv = '\uFEFF';
    if (type === 'saisies' || type === 'complet') {
      csv += '=== SAISIES ===\n';
      csv += 'Date;Type;Projet;Heures;Commentaire;Statut\n';
      filteredSaisies.forEach(s => {
        csv += `${s.date};${s.typeActivite};${getProjetDisplay(s.projetId)};${s.heures};${s.commentaire || ''};${STATUT_LABEL[s.statut] || s.statut}\n`;
      });
      csv += `;;;Total: ${totalHeures}h;;\n`;
    }
    if (type === 'conges' || type === 'complet') {
      if (type === 'complet') csv += '\n';
      csv += '=== CONGÉS ===\n';
      csv += 'Date demande;Type;Début;Fin;Nb jours;Motif;Statut\n';
      filteredConges.forEach(c => {
        csv += `${c.createdAt.slice(0, 10)};${c.typeConge};${c.dateDebut};${c.dateFin};${c.nbJours};${c.motif || ''};${c.statut}\n`;
      });
      csv += `;;;;Total: ${totalJours} j;;\n`;
    }
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rapport_${type}_${format(new Date(), 'yyyyMMdd')}.csv`;
    a.click(); URL.revokeObjectURL(url);
  };

  const uniqueTypes = [...new Set(saisies.map(s => s.typeActivite))].sort();
  const activeProjets = projets.filter(p => p.statut === 'actif');

  return (
    <Layout title="Rapports & Analyses">
      {/* Export buttons */}
      <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginBottom: 20, flexWrap: 'wrap' }}>
        <button onClick={() => exportCSV('saisies')} className="btn-secondary">
          <Download size={13} /> Saisies CSV
        </button>
        <button onClick={() => exportCSV('conges')} className="btn-secondary">
          <Download size={13} /> Congés CSV
        </button>
        <button onClick={() => exportCSV('complet')} className="btn-primary">
          <Download size={13} /> Rapport complet CSV
        </button>
      </div>

      {/* Filters */}
      <div className="card" style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ink)', marginBottom: 12 }}>Filtres</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, alignItems: 'flex-end' }}>
          <div style={{ flex: '1 1 160px' }}>
            <label className="form-label">Type d'activité</label>
            <select value={filterType} onChange={e => setFilterType(e.target.value)} className="form-input">
              <option value="">Tous</option>
              {uniqueTypes.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div style={{ flex: '1 1 160px' }}>
            <label className="form-label">Projet</label>
            <select value={filterProjet} onChange={e => setFilterProjet(e.target.value)} className="form-input">
              <option value="">Tous</option>
              {activeProjets.map(p => (
                <option key={p.id} value={p.id.toString()}>
                  {p.client ? `${p.client} — ${p.nom}` : p.nom}
                </option>
              ))}
            </select>
          </div>
          <div style={{ flex: '1 1 140px' }}>
            <label className="form-label">Début</label>
            <input type="date" value={filterDateDebut} onChange={e => setFilterDateDebut(e.target.value)} className="form-input" />
          </div>
          <div style={{ flex: '1 1 140px' }}>
            <label className="form-label">Fin</label>
            <input type="date" value={filterDateFin} onChange={e => setFilterDateFin(e.target.value)} className="form-input" />
          </div>
          <button
            onClick={() => { setFilterType(''); setFilterProjet(''); setFilterDateDebut(''); setFilterDateFin(''); }}
            className="btn-secondary" style={{ padding: '9px 14px' }}
          >
            Réinitialiser
          </button>
        </div>
      </div>

      {/* Summary stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }}>
        {[
          { label: 'Total saisies', value: filteredSaisies.length, color: '#2563EB', bg: '#EFF6FF' },
          { label: 'Total heures', value: `${totalHeures}h`, color: '#7C3AED', bg: '#F5F3FF' },
          { label: 'Demandes congé', value: filteredConges.length, color: '#059669', bg: '#ECFDF5' },
          { label: 'Jours de congé', value: `${totalJours}j`, color: '#D97706', bg: '#FFFBEB' },
        ].map(stat => (
          <div key={stat.label} className="card" style={{ padding: '16px 20px' }}>
            <div style={{ fontSize: 28, fontWeight: 300, color: stat.color, letterSpacing: '-1px' }}>{stat.value}</div>
            <div style={{ fontSize: 12, color: 'var(--ink-faint)', marginTop: 4 }}>{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Charts row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 24 }}>
        {/* Monthly bars */}
        <div className="card">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
            <BarChart3 size={16} color="var(--accent)" />
            <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink)' }}>Heures par mois</span>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={monthlyData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
              <XAxis dataKey="mois" tick={{ fontSize: 11, fill: '#9CA3AF' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#9CA3AF' }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ borderRadius: 8, border: '1px solid var(--border)', fontSize: 12 }} />
              <Bar dataKey="heures" fill="#2563EB" radius={[5, 5, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Pie chart */}
        <div className="card">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
            <PieChart size={16} color="var(--accent)" />
            <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink)' }}>Répartition par activité</span>
          </div>
          {typeData.length === 0 ? (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: 200, color: 'var(--ink-faint)', fontSize: 13 }}>
              Aucune donnée
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={200}>
              <RechartsPie>
                <Pie data={typeData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} labelLine={false}>
                  {typeData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: 8, border: '1px solid var(--border)', fontSize: 12 }} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
              </RechartsPie>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* Project chart */}
      {projetData.length > 0 && (
        <div className="card" style={{ marginBottom: 24 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
            <TrendingUp size={16} color="var(--accent)" />
            <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink)' }}>Heures par projet</span>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={projetData} layout="vertical" margin={{ top: 0, right: 20, left: 0, bottom: 0 }}>
              <XAxis type="number" tick={{ fontSize: 11, fill: '#9CA3AF' }} axisLine={false} tickLine={false} />
              <YAxis type="category" dataKey="nom" tick={{ fontSize: 11, fill: '#6B7280' }} axisLine={false} tickLine={false} width={100} />
              <Tooltip contentStyle={{ borderRadius: 8, border: '1px solid var(--border)', fontSize: 12 }} />
              <Bar dataKey="heures" fill="#7C3AED" radius={[0, 5, 5, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Tables */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        {/* Saisies table */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: 8 }}>
            <FileText size={14} color="var(--accent)" />
            <span style={{ fontSize: 14, fontWeight: 600 }}>Historique des saisies</span>
            <span style={{ marginLeft: 'auto', fontSize: 12, color: 'var(--ink-faint)' }}>{filteredSaisies.length} entrée(s)</span>
          </div>
          <div style={{ overflowX: 'auto', maxHeight: 340, overflowY: 'auto' }}>
            <table className="data-table">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Type</th>
                  <th>Heures</th>
                  <th>Statut</th>
                </tr>
              </thead>
              <tbody>
                {filteredSaisies.length === 0 ? (
                  <tr><td colSpan={4} style={{ textAlign: 'center', padding: 24, color: 'var(--ink-faint)', fontSize: 12 }}>Aucune saisie</td></tr>
                ) : filteredSaisies.map(s => (
                  <tr key={s.id}>
                    <td style={{ fontSize: 12 }}>{s.date}</td>
                    <td><span className={`badge ${BADGE_MAP[s.typeActivite] || 'badge-gray'}`} style={{ fontSize: 10 }}>{s.typeActivite.length > 18 ? s.typeActivite.slice(0, 18) + '…' : s.typeActivite}</span></td>
                    <td style={{ fontWeight: 600, fontSize: 13 }}>{s.heures}h</td>
                    <td>
                      <span className={`badge status-${s.statut}`} style={{ fontSize: 10 }}>
                        {STATUT_LABEL[s.statut] || s.statut}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
              {filteredSaisies.length > 0 && (
                <tfoot>
                  <tr style={{ background: 'var(--cream)' }}>
                    <td colSpan={2} style={{ textAlign: 'right', fontWeight: 600, fontSize: 12 }}>TOTAL</td>
                    <td style={{ fontWeight: 700 }}>{totalHeures}h</td>
                    <td />
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </div>

        {/* Congés table */}
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: 8 }}>
            <FileText size={14} color="#D97706" />
            <span style={{ fontSize: 14, fontWeight: 600 }}>Demandes de congé</span>
            <span style={{ marginLeft: 'auto', fontSize: 12, color: 'var(--ink-faint)' }}>{filteredConges.length} demande(s)</span>
          </div>
          <div style={{ overflowX: 'auto', maxHeight: 340, overflowY: 'auto' }}>
            <table className="data-table">
              <thead>
                <tr>
                  <th>Début</th>
                  <th>Fin</th>
                  <th>Jours</th>
                  <th>Statut</th>
                </tr>
              </thead>
              <tbody>
                {filteredConges.length === 0 ? (
                  <tr><td colSpan={4} style={{ textAlign: 'center', padding: 24, color: 'var(--ink-faint)', fontSize: 12 }}>Aucun congé</td></tr>
                ) : filteredConges.map(c => (
                  <tr key={c.id}>
                    <td style={{ fontSize: 12 }}>{c.dateDebut}</td>
                    <td style={{ fontSize: 12 }}>{c.dateFin}</td>
                    <td style={{ fontWeight: 600 }}>{c.nbJours}j</td>
                    <td>
                      <span className={`badge status-${c.statut}`} style={{ fontSize: 10 }}>
                        {c.statut === 'en_attente' ? 'En attente' : c.statut === 'approuve' ? 'Approuvé' : 'Refusé'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
              {filteredConges.length > 0 && (
                <tfoot>
                  <tr style={{ background: 'var(--cream)' }}>
                    <td colSpan={2} style={{ textAlign: 'right', fontWeight: 600, fontSize: 12 }}>TOTAL</td>
                    <td style={{ fontWeight: 700 }}>{totalJours}j</td>
                    <td />
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </div>
      </div>
    </Layout>
  );
}
