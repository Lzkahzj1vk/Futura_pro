'use client';

import { useState, useMemo } from 'react';
import { FileText, Download, Clock } from 'lucide-react';
import Layout from '../../components/Layout';
import { useApp } from '../../context/AppContext';
import { BADGE_MAP } from '../../data/mockData';
import { format } from 'date-fns';

const STATUT_LABEL: Record<string, string> = {
  en_attente: 'En attente', valide: 'Validé', rejete: 'Rejeté', approuve: 'Approuvé', refuse: 'Refusé',
};

export default function Rapports() {
  const { saisies, projets } = useApp();

  const [filterProjet, setFilterProjet] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterDateDebut, setFilterDateDebut] = useState('');
  const [filterDateFin, setFilterDateFin] = useState('');

  const filteredSaisies = useMemo(() => {
    return saisies.filter(s => {
      if (filterProjet && s.projetId?.toString() !== filterProjet) return false;
      if (filterType && s.typeActivite !== filterType) return false;
      if (filterDateDebut && s.date < filterDateDebut) return false;
      if (filterDateFin && s.date > filterDateFin) return false;
      return true;
    });
  }, [saisies, filterProjet, filterType, filterDateDebut, filterDateFin]);

  const totalHeures = filteredSaisies.reduce((acc, s) => acc + s.heures, 0);

  const getProjetDisplay = (projetId: number | null) => {
    if (!projetId) return 'Interne';
    const p = projets.find(x => x.id === projetId);
    if (!p) return 'Interne';
    return p.client ? `${p.client} — ${p.nom}` : p.nom;
  };

  const exportSaisiesCSV = () => {
    let csv = '\uFEFF';
    csv += 'Date;Type;Projet;Heures;Commentaire;Statut\n';
    filteredSaisies.forEach(s => {
      csv += `${s.date};${s.typeActivite};${getProjetDisplay(s.projetId)};${s.heures};${s.commentaire || ''};${STATUT_LABEL[s.statut] || s.statut}\n`;
    });
    csv += `;;;Total: ${totalHeures}h;;\n`;
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rapport_saisies_${format(new Date(), 'yyyyMMdd')}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const uniqueTypes = [...new Set(saisies.map(s => s.typeActivite))].sort();
  const activeProjets = projets.filter(p => p.statut === 'actif');

  // Par projet
  const parProjet = useMemo(() => {
    const map: Record<string, { nom: string; heures: number; count: number }> = {};
    filteredSaisies.forEach(s => {
      const key = s.projetId?.toString() || 'interne';
      if (!map[key]) map[key] = { nom: getProjetDisplay(s.projetId), heures: 0, count: 0 };
      map[key].heures += s.heures;
      map[key].count++;
    });
    return Object.values(map).sort((a, b) => b.heures - a.heures);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filteredSaisies]);

  // Par type d'activité
  const parType = useMemo(() => {
    const map: Record<string, { heures: number; count: number }> = {};
    filteredSaisies.forEach(s => {
      if (!map[s.typeActivite]) map[s.typeActivite] = { heures: 0, count: 0 };
      map[s.typeActivite].heures += s.heures;
      map[s.typeActivite].count++;
    });
    return Object.entries(map).sort((a, b) => b[1].heures - a[1].heures);
  }, [filteredSaisies]);

  return (
    <Layout title="Rapports & Analyses">

      {/* Export button */}
      <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginBottom: 20 }}>
        <button onClick={exportSaisiesCSV} className="btn-primary">
          <Download size={13} /> Exporter saisies CSV
        </button>
      </div>

      {/* Filtres */}
      <div className="card" style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ink)', marginBottom: 12 }}>Filtres</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, alignItems: 'flex-end' }}>
          <div style={{ flex: '1 1 160px' }}>
            <label className="form-label">Projet</label>
            <select value={filterProjet} onChange={e => setFilterProjet(e.target.value)} className="form-input">
              <option value="">Tous</option>
              {activeProjets.map(p => (
                <option key={p.id} value={p.id.toString()}>
                  {p.client ? `${p.client} — ${p.nom}` : p.nom}
                </option>
              ))}
            </select>
          </div>
          <div style={{ flex: '1 1 160px' }}>
            <label className="form-label">Type d&apos;activité</label>
            <select value={filterType} onChange={e => setFilterType(e.target.value)} className="form-input">
              <option value="">Tous</option>
              {uniqueTypes.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div style={{ flex: '1 1 140px' }}>
            <label className="form-label">Début</label>
            <input type="date" value={filterDateDebut} onChange={e => setFilterDateDebut(e.target.value)} className="form-input" />
          </div>
          <div style={{ flex: '1 1 140px' }}>
            <label className="form-label">Fin</label>
            <input type="date" value={filterDateFin} onChange={e => setFilterDateFin(e.target.value)} className="form-input" />
          </div>
          <button
            onClick={() => { setFilterProjet(''); setFilterType(''); setFilterDateDebut(''); setFilterDateFin(''); }}
            className="btn-secondary" style={{ padding: '9px 14px' }}
          >
            Réinitialiser
          </button>
        </div>
      </div>

      {/* Summary */}
      <div style={{ display: 'flex', gap: 16, marginBottom: 24, flexWrap: 'wrap' }}>
        <div className="card" style={{ padding: '16px 22px', display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ width: 44, height: 44, background: '#EFF6FF', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Clock size={20} color="#2563EB" />
          </div>
          <div>
            <div style={{ fontSize: 32, fontWeight: 300, color: '#2563EB', letterSpacing: '-1px' }}>{totalHeures}h</div>
            <div style={{ fontSize: 12, color: 'var(--ink-faint)', marginTop: 2 }}>
              Total heures ({filteredSaisies.length} saisie{filteredSaisies.length > 1 ? 's' : ''})
            </div>
          </div>
        </div>
        <div className="card" style={{ padding: '16px 22px', display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ width: 44, height: 44, background: '#F5F3FF', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <FileText size={20} color="#7C3AED" />
          </div>
          <div>
            <div style={{ fontSize: 32, fontWeight: 300, color: '#7C3AED', letterSpacing: '-1px' }}>{filteredSaisies.length}</div>
            <div style={{ fontSize: 12, color: 'var(--ink-faint)', marginTop: 2 }}>Saisies filtrées</div>
          </div>
        </div>
        {filteredSaisies.length > 0 && (
          <div className="card" style={{ padding: '16px 22px', display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{ width: 44, height: 44, background: '#ECFDF5', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Clock size={20} color="#059669" />
            </div>
            <div>
              <div style={{ fontSize: 32, fontWeight: 300, color: '#059669', letterSpacing: '-1px' }}>
                {(totalHeures / filteredSaisies.length).toFixed(1)}h
              </div>
              <div style={{ fontSize: 12, color: 'var(--ink-faint)', marginTop: 2 }}>Moyenne / saisie</div>
            </div>
          </div>
        )}
      </div>

      {/* Two-column breakdown */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 20, marginBottom: 24 }}>
        {/* Par projet */}
        <div className="card">
          <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink)', marginBottom: 16 }}>
            Heures par projet
          </div>
          {parProjet.length === 0 ? (
            <div style={{ color: 'var(--ink-faint)', fontSize: 13 }}>Aucune donnée</div>
          ) : parProjet.map((p, i) => (
            <div key={i} style={{ marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span style={{ fontSize: 12, color: 'var(--ink)', fontWeight: 500, maxWidth: '70%', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {p.nom}
                </span>
                <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--accent)' }}>{p.heures}h</span>
              </div>
              <div style={{ height: 6, background: '#E5E7EB', borderRadius: 3, overflow: 'hidden' }}>
                <div style={{
                  height: '100%',
                  background: 'linear-gradient(90deg, #2563EB, #7C3AED)',
                  borderRadius: 3,
                  width: `${totalHeures > 0 ? (p.heures / totalHeures) * 100 : 0}%`,
                  transition: 'width 0.5s ease',
                }} />
              </div>
            </div>
          ))}
        </div>

        {/* Par type */}
        <div className="card">
          <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink)', marginBottom: 16 }}>
            Heures par type d&apos;activité
          </div>
          {parType.length === 0 ? (
            <div style={{ color: 'var(--ink-faint)', fontSize: 13 }}>Aucune donnée</div>
          ) : parType.slice(0, 8).map(([type, data]) => (
            <div key={type} style={{ marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span className={`badge ${BADGE_MAP[type] || 'badge-gray'}`} style={{ fontSize: 10 }}>
                  {type}
                </span>
                <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--ink-soft)' }}>{data.heures}h · {data.count} saisie{data.count > 1 ? 's' : ''}</span>
              </div>
              <div style={{ height: 6, background: '#E5E7EB', borderRadius: 3, overflow: 'hidden' }}>
                <div style={{
                  height: '100%',
                  background: '#7C3AED',
                  borderRadius: 3,
                  width: `${totalHeures > 0 ? (data.heures / totalHeures) * 100 : 0}%`,
                  transition: 'width 0.5s ease',
                }} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Detail table */}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border)' }}>
          <h3 style={{ margin: 0, fontSize: 15, fontWeight: 600, color: 'var(--ink)' }}>
            Détail des saisies
          </h3>
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table className="data-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Type</th>
                <th>Projet</th>
                <th>Heures</th>
                <th>Statut</th>
              </tr>
            </thead>
            <tbody>
              {filteredSaisies.length === 0 ? (
                <tr>
                  <td colSpan={5} style={{ textAlign: 'center', padding: 48, color: 'var(--ink-faint)' }}>
                    <div style={{ fontSize: 28, marginBottom: 8 }}>📊</div>
                    Aucune saisie trouvée
                  </td>
                </tr>
              ) : filteredSaisies.slice(0, 50).map(s => (
                <tr key={s.id}>
                  <td style={{ fontSize: 12 }}>{s.date}</td>
                  <td>
                    <span className={`badge ${BADGE_MAP[s.typeActivite] || 'badge-gray'}`} style={{ fontSize: 10 }}>
                      {s.typeActivite}
                    </span>
                  </td>
                  <td style={{ fontSize: 12 }}>{getProjetDisplay(s.projetId)}</td>
                  <td style={{ fontWeight: 600 }}>{s.heures}h</td>
                  <td>
                    <span className={`badge status-${s.statut}`} style={{ fontSize: 10 }}>
                      {STATUT_LABEL[s.statut] || s.statut}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </Layout>
  );
}
