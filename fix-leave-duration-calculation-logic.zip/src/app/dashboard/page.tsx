'use client';

import { useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { Clock, FolderOpen, CalendarCheck, TrendingUp, Plus, ArrowRight } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import Layout from '../../components/Layout';
import { useApp } from '../../context/AppContext';
import { BADGE_MAP } from '../../data/mockData';
import { format, startOfWeek, endOfWeek, startOfMonth, isWithinInterval, parseISO, addDays } from 'date-fns';
import { fr } from 'date-fns/locale';

const DAYS = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven'];
const ACCENT = '#2563EB';

export default function Dashboard() {
  const { user, saisies, projets } = useApp();
  const router = useRouter();
  const today = new Date();

  const weekStart = startOfWeek(today, { weekStartsOn: 1 });
  const weekEnd = endOfWeek(today, { weekStartsOn: 1 });
  const monthStart = startOfMonth(today);

  const heuresSemaine = useMemo(() => {
    return saisies
      .filter(s => {
        const d = parseISO(s.date);
        return isWithinInterval(d, { start: weekStart, end: weekEnd });
      })
      .reduce((acc, s) => acc + s.heures, 0);
  }, [saisies, weekStart, weekEnd]);

  const heuresMois = useMemo(() => {
    return saisies
      .filter(s => parseISO(s.date) >= monthStart)
      .reduce((acc, s) => acc + s.heures, 0);
  }, [saisies, monthStart]);

  const projetsActifs = useMemo(() => {
    const projetIds = new Set(saisies.map(s => s.projetId).filter(Boolean));
    return projets.filter(p => p.statut === 'actif' && projetIds.has(p.id)).length;
  }, [saisies, projets]);

  const saisiesSemaine = useMemo(() => {
    return saisies.filter(s => {
      const d = parseISO(s.date);
      return isWithinInterval(d, { start: weekStart, end: weekEnd });
    }).length;
  }, [saisies, weekStart, weekEnd]);

  const weekBars = useMemo(() => {
    return DAYS.map((day, i) => {
      const d = addDays(weekStart, i);
      const dStr = format(d, 'yyyy-MM-dd');
      const h = saisies
        .filter(s => s.date === dStr)
        .reduce((acc, s) => acc + s.heures, 0);
      return { day, heures: h, date: dStr };
    });
  }, [saisies, weekStart]);

  const maxH = Math.max(...weekBars.map(b => b.heures), 8);

  const recentSaisies = useMemo(() =>
    [...saisies].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 5),
    [saisies]
  );

  const getProjetDisplay = (projetId: number | null) => {
    if (!projetId) return 'Interne';
    const p = projets.find(x => x.id === projetId);
    if (!p) return 'Interne';
    return p.client ? `${p.client} — ${p.nom}` : p.nom;
  };

  const getBadge = (type: string) => BADGE_MAP[type] || 'badge-gray';

  const statCards = [
    {
      label: 'Heures cette semaine',
      value: `${heuresSemaine}h`,
      icon: Clock, color: '#2563EB', bg: '#EFF6FF',
      sub: `Semaine du ${format(weekStart, 'dd MMM', { locale: fr })}`,
    },
    {
      label: 'Heures ce mois',
      value: `${heuresMois}h`,
      icon: TrendingUp, color: '#7C3AED', bg: '#F5F3FF',
      sub: format(today, 'MMMM yyyy', { locale: fr }),
    },
    {
      label: 'Projets actifs',
      value: projetsActifs,
      icon: FolderOpen, color: '#059669', bg: '#ECFDF5',
      sub: 'Projets en cours',
    },
    {
      label: 'Saisies cette semaine',
      value: saisiesSemaine,
      icon: CalendarCheck, color: '#D97706', bg: '#FFFBEB',
      sub: 'Entrées enregistrées',
    },
  ];

  return (
    <Layout title="Tableau de bord">
      {/* Welcome */}
      <div style={{ marginBottom: 24 }}>
        <h2 style={{ fontSize: 20, fontWeight: 700, margin: '0 0 4px', color: 'var(--ink)' }}>
          Bonjour, {user?.prenom} {user?.nom} 👋
        </h2>
        <p style={{ fontSize: 13, color: 'var(--ink-soft)', margin: 0 }}>
          Voici un aperçu de votre activité — {format(today, 'EEEE d MMMM yyyy', { locale: fr })}
        </p>
      </div>

      {/* Stat cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 16, marginBottom: 24 }}>
        {statCards.map(({ label, value, icon: Icon, color, bg, sub }) => (
          <div key={label} className="card" style={{ padding: '20px 22px' }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 12 }}>
              <div>
                <div style={{ fontSize: 11, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px', color: 'var(--ink-soft)', marginBottom: 6 }}>
                  {label}
                </div>
                <div style={{ fontSize: 32, fontWeight: 300, color: 'var(--ink)', letterSpacing: '-1px', lineHeight: 1 }}>
                  {value}
                </div>
              </div>
              <div style={{ width: 40, height: 40, borderRadius: 10, background: bg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <Icon size={18} color={color} />
              </div>
            </div>
            <div style={{ fontSize: 11, color: 'var(--ink-faint)' }}>{sub}</div>
          </div>
        ))}
      </div>

      {/* Charts + recent */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 20 }}>
        {/* Week Chart */}
        <div className="card">
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink)' }}>Activité de la semaine</div>
            <div style={{ fontSize: 12, color: 'var(--ink-faint)', marginTop: 2 }}>
              Semaine du {format(weekStart, 'dd', { locale: fr })} au {format(weekEnd, 'dd MMMM', { locale: fr })}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={weekBars} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
              <XAxis dataKey="day" tick={{ fontSize: 11, fill: '#9CA3AF' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#9CA3AF' }} axisLine={false} tickLine={false} domain={[0, maxH + 1]} />
              <Tooltip
                contentStyle={{ borderRadius: 8, border: '1px solid var(--border)', fontSize: 12 }}
                formatter={(v) => [`${v}h`, 'Heures']}
                labelStyle={{ fontWeight: 600 }}
              />
              <Bar dataKey="heures" radius={[6, 6, 0, 0]}>
                {weekBars.map((entry, idx) => (
                  <Cell
                    key={idx}
                    fill={entry.heures > 0 ? ACCENT : '#E5E7EB'}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>

          {/* Summary row */}
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 12, paddingTop: 12, borderTop: '1px solid var(--border)' }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 18, fontWeight: 600, color: 'var(--ink)' }}>{heuresSemaine}h</div>
              <div style={{ fontSize: 11, color: 'var(--ink-faint)' }}>Total</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 18, fontWeight: 600, color: 'var(--ink)' }}>
                {saisiesSemaine}
              </div>
              <div style={{ fontSize: 11, color: 'var(--ink-faint)' }}>Saisies</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 18, fontWeight: 600, color: 'var(--ink)' }}>
                {weekBars.filter(b => b.heures > 0).length}/5
              </div>
              <div style={{ fontSize: 11, color: 'var(--ink-faint)' }}>Jours saisis</div>
            </div>
          </div>
        </div>

        {/* Recent saisies */}
        <div className="card">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
            <div>
              <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink)' }}>Dernières saisies</div>
              <div style={{ fontSize: 12, color: 'var(--ink-faint)', marginTop: 2 }}>Activités récentes</div>
            </div>
            <button
              onClick={() => router.push('/historique')}
              style={{
                display: 'flex', alignItems: 'center', gap: 4,
                background: 'none', border: 'none', color: 'var(--accent)',
                cursor: 'pointer', fontSize: 12, fontWeight: 500,
              }}
            >
              Voir tout <ArrowRight size={12} />
            </button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {recentSaisies.length === 0 ? (
              <div style={{ textAlign: 'center', color: 'var(--ink-faint)', fontSize: 13, padding: '32px 0' }}>
                Aucune saisie pour le moment
              </div>
            ) : recentSaisies.map(s => (
              <div key={s.id} style={{
                display: 'flex', alignItems: 'center', gap: 12,
                padding: '10px 12px', borderRadius: 10, background: 'var(--cream)',
              }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3 }}>
                    <span className={`badge ${getBadge(s.typeActivite)}`} style={{ fontSize: 10, maxWidth: 180, overflow: 'hidden', textOverflow: 'ellipsis' }}>{s.typeActivite}</span>
                  </div>
                  <div style={{ fontSize: 11, color: 'var(--ink-faint)' }}>
                    {getProjetDisplay(s.projetId)} · {format(parseISO(s.date), 'dd/MM/yyyy')}
                  </div>
                </div>
                <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink)', whiteSpace: 'nowrap' }}>
                  {s.heures}h
                </div>
              </div>
            ))}
          </div>

          <button
            onClick={() => router.push('/saisie')}
            className="btn-primary"
            style={{ width: '100%', justifyContent: 'center', marginTop: 16 }}
          >
            <Plus size={14} />
            Nouvelle saisie
          </button>
        </div>
      </div>
    </Layout>
  );
}
