'use client';

import { useState, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { Filter, Pencil, Trash2, ChevronLeft, ChevronRight, Clock, Download } from 'lucide-react';
import Layout from '../../components/Layout';
import { useApp } from '../../context/AppContext';
import { BADGE_MAP } from '../../data/mockData';
import { format, parseISO } from 'date-fns';
import { calcJoursOuvrables } from '../../utils/dateUtils';

const PER_PAGE = 10;

const STATUT_LABEL: Record<string, string> = {
  en_attente: 'En attente',
  valide: 'Validé',
  rejete: 'Rejeté',
  approuve: 'Approuvé',
  refuse: 'Refusé',
};

export default function Historique() {
  const { saisies, projets, deleteSaisie, addFlash } = useApp();
  const router = useRouter();
  const [filterType, setFilterType] = useState('');
  const [filterProjet, setFilterProjet] = useState('');
  const [filterDateDebut, setFilterDateDebut] = useState('');
  const [filterDateFin, setFilterDateFin] = useState('');
  const [page, setPage] = useState(1);
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);

  const getProjetDisplay = (projetId: number | null) => {
    if (!projetId) return 'Interne';
    const p = projets.find(x => x.id === projetId);
    if (!p) return 'Interne';
    return p.client ? `${p.client} — ${p.nom}` : p.nom;
  };

  const filtered = useMemo(() => {
    return saisies.filter(s => {
      if (filterType && s.typeActivite !== filterType) return false;
      if (filterProjet && s.projetId?.toString() !== filterProjet) return false;
      if (filterDateDebut && s.date < filterDateDebut) return false;
      if (filterDateFin && s.date > filterDateFin) return false;
      return true;
    }).sort((a, b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt));
  }, [saisies, filterType, filterProjet, filterDateDebut, filterDateFin]);

  const totalHeures = filtered.reduce((acc, s) => acc + s.heures, 0);
  const totalPages = Math.max(Math.ceil(filtered.length / PER_PAGE), 1);
  const pageSaisies = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);
  const pageHeures = pageSaisies.reduce((acc, s) => acc + s.heures, 0);

  const handleDelete = (id: number) => {
    deleteSaisie(id);
    setDeleteConfirm(null);
    addFlash('info', 'Saisie supprimée.');
  };

  const exportCSV = () => {
    const rows = [['Date', 'Type', 'Projet', 'Heures / Jours', 'Commentaire', 'Statut']];
    filtered.forEach(s => {
      rows.push([
        s.date, s.typeActivite, getProjetDisplay(s.projetId),
        formatHeures(s), s.commentaire, STATUT_LABEL[s.statut] || s.statut
      ]);
    });
    rows.push(['', '', 'TOTAL', `${totalHeures}h`, '', '']);
    const csv = '\uFEFF' + rows.map(r => r.map(c => `"${c}"`).join(';')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `saisies_${format(new Date(), 'yyyyMMdd')}.csv`;
    a.click(); URL.revokeObjectURL(url);
  };

  const uniqueTypes = [...new Set(saisies.map(s => s.typeActivite))].sort();
  const activeProjets = projets.filter(p => p.statut === 'actif');

  const formatDate = (s: typeof saisies[0]) => {
    if (s.typeActivite === 'Congé' && s.congeDateDebut && s.congeDateFin && s.congeDateDebut !== s.congeDateFin) {
      return `${format(parseISO(s.congeDateDebut), 'dd/MM/yyyy')} → ${format(parseISO(s.congeDateFin), 'dd/MM/yyyy')}`;
    }
    return format(parseISO(s.date), 'dd/MM/yyyy');
  };

  const formatHeures = (s: typeof saisies[0]) => {
    if (s.typeActivite === 'Congé') {
      if (s.congeDateDebut && s.congeDateFin && s.congeDateDebut !== s.congeDateFin) {
        // Use working days count (exclude weekends)
        const nb = calcJoursOuvrables(s.congeDateDebut, s.congeDateFin);
        return `${nb} j ouv.`;
      }
      return s.heures === 4 ? 'Demi-j' : '1 j';
    }
    return `${s.heures}h`;
  };

  return (
    <Layout title="Historique des saisies">
      {/* Filters */}
      <div className="card" style={{ marginBottom: 20 }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, alignItems: 'flex-end' }}>
          <div style={{ flex: '1 1 160px' }}>
            <label className="form-label">Type d&apos;activité</label>
            <select
              value={filterType}
              onChange={e => { setFilterType(e.target.value); setPage(1); }}
              className="form-input"
            >
              <option value="">Tous les types</option>
              {uniqueTypes.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div style={{ flex: '1 1 160px' }}>
            <label className="form-label">Projet</label>
            <select
              value={filterProjet}
              onChange={e => { setFilterProjet(e.target.value); setPage(1); }}
              className="form-input"
            >
              <option value="">Tous les projets</option>
              {activeProjets.map(p => (
                <option key={p.id} value={p.id.toString()}>
                  {p.client ? `${p.client} — ${p.nom}` : p.nom}
                </option>
              ))}
            </select>
          </div>
          <div style={{ flex: '1 1 140px' }}>
            <label className="form-label">Date début</label>
            <input
              type="date"
              value={filterDateDebut}
              onChange={e => { setFilterDateDebut(e.target.value); setPage(1); }}
              className="form-input"
            />
          </div>
          <div style={{ flex: '1 1 140px' }}>
            <label className="form-label">Date fin</label>
            <input
              type="date"
              value={filterDateFin}
              onChange={e => { setFilterDateFin(e.target.value); setPage(1); }}
              className="form-input"
            />
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button
              onClick={() => { setFilterType(''); setFilterProjet(''); setFilterDateDebut(''); setFilterDateFin(''); setPage(1); }}
              className="btn-secondary"
              style={{ padding: '9px 14px' }}
            >
              Réinitialiser
            </button>
            <button onClick={exportCSV} className="btn-secondary" style={{ padding: '9px 14px' }}>
              <Download size={13} /> CSV
            </button>
          </div>
        </div>
      </div>

      {/* Stats bar */}
      <div style={{ display: 'flex', gap: 16, marginBottom: 16, flexWrap: 'wrap' }}>
        <div className="card" style={{ padding: '12px 18px', display: 'flex', alignItems: 'center', gap: 10 }}>
          <Clock size={16} style={{ color: 'var(--accent)' }} />
          <div>
            <div style={{ fontSize: 18, fontWeight: 700, color: 'var(--ink)' }}>{totalHeures}h</div>
            <div style={{ fontSize: 11, color: 'var(--ink-faint)' }}>Total ({filtered.length} saisies)</div>
          </div>
        </div>
        <div className="card" style={{ padding: '12px 18px', display: 'flex', alignItems: 'center', gap: 10 }}>
          <Filter size={16} style={{ color: 'var(--accent)' }} />
          <div>
            <div style={{ fontSize: 18, fontWeight: 700, color: 'var(--ink)' }}>{pageHeures}h</div>
            <div style={{ fontSize: 11, color: 'var(--ink-faint)' }}>Page {page} ({pageSaisies.length} saisies)</div>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{ overflowX: 'auto' }}>
          <table className="data-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Projet</th>
                <th>Type d&apos;activité</th>
                <th>Commentaire</th>
                <th>Heures / Jours</th>
                <th>Statut</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {pageSaisies.length === 0 ? (
                <tr>
                  <td colSpan={7} style={{ textAlign: 'center', padding: 48, color: 'var(--ink-faint)', fontSize: 13 }}>
                    <div style={{ marginBottom: 8, fontSize: 28 }}>📋</div>
                    Aucune saisie trouvée
                  </td>
                </tr>
              ) : pageSaisies.map(s => (
                <tr key={s.id}>
                  <td style={{ fontSize: 12, whiteSpace: 'nowrap' }}>
                    {formatDate(s)}
                  </td>
                  <td style={{ fontSize: 12, maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {getProjetDisplay(s.projetId)}
                  </td>
                  <td>
                    <span className={`badge ${BADGE_MAP[s.typeActivite] || 'badge-gray'}`}>
                      {s.typeActivite}
                    </span>
                  </td>
                  <td style={{ fontSize: 12, color: 'var(--ink-soft)', maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {s.commentaire || '—'}
                  </td>
                  <td style={{ fontWeight: 600, whiteSpace: 'nowrap' }}>
                    {formatHeures(s)}
                  </td>
                  <td>
                    <span className={`badge status-${s.statut}`} style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                      {s.statut === 'en_attente' ? '⏳' : s.statut === 'valide' || s.statut === 'approuve' ? '✓' : '✗'}
                      {' '}{STATUT_LABEL[s.statut] || s.statut}
                    </span>
                  </td>
                  <td>
                    <div style={{ display: 'flex', gap: 6 }}>
                      <button
                        onClick={() => router.push(`/saisie/${s.id}/edit`)}
                        style={{
                          width: 30, height: 30, borderRadius: 8,
                          border: '1px solid var(--border)', background: 'transparent',
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                          cursor: 'pointer', color: 'var(--ink-soft)',
                        }}
                        title="Modifier"
                      >
                        <Pencil size={13} />
                      </button>
                      {deleteConfirm === s.id ? (
                        <div style={{ display: 'flex', gap: 4 }}>
                          <button
                            onClick={() => handleDelete(s.id)}
                            style={{
                              padding: '4px 10px', borderRadius: 8, fontSize: 11,
                              border: 'none', background: '#DC2626', color: 'white',
                              cursor: 'pointer',
                            }}
                          >
                            Confirmer
                          </button>
                          <button
                            onClick={() => setDeleteConfirm(null)}
                            style={{
                              padding: '4px 10px', borderRadius: 8, fontSize: 11,
                              border: '1px solid var(--border)', background: 'transparent',
                              cursor: 'pointer',
                            }}
                          >
                            Non
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setDeleteConfirm(s.id)}
                          style={{
                            width: 30, height: 30, borderRadius: 8,
                            border: '1px solid #FECACA', background: '#FEF2F2',
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                            cursor: 'pointer', color: '#DC2626',
                          }}
                          title="Supprimer"
                        >
                          <Trash2 size={13} />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '12px 20px', borderTop: '1px solid var(--border)',
          }}>
            <div style={{ fontSize: 12, color: 'var(--ink-faint)' }}>
              Page {page} / {totalPages} · {filtered.length} résultats
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page === 1}
                style={{
                  width: 32, height: 32, borderRadius: 8,
                  border: '1px solid var(--border)', background: 'transparent',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  cursor: page === 1 ? 'not-allowed' : 'pointer',
                  opacity: page === 1 ? 0.4 : 1,
                }}
              >
                <ChevronLeft size={14} />
              </button>
              <button
                onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                style={{
                  width: 32, height: 32, borderRadius: 8,
                  border: '1px solid var(--border)', background: 'transparent',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  cursor: page === totalPages ? 'not-allowed' : 'pointer',
                  opacity: page === totalPages ? 0.4 : 1,
                }}
              >
                <ChevronRight size={14} />
              </button>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
