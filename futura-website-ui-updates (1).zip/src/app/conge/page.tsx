'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { CalendarOff, Plus, Clock, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import Layout from '../../components/Layout';
import { useApp } from '../../context/AppContext';
import { TYPES_CONGE } from '../../data/mockData';
import { format, parseISO } from 'date-fns';

const STATUT_LABEL: Record<string, { label: string; icon: string; cls: string }> = {
  en_attente: { label: 'En attente', icon: '⏳', cls: 'status-en_attente' },
  approuve: { label: 'Approuvé', icon: '✓', cls: 'status-approuve' },
  refuse: { label: 'Refusé', icon: '✗', cls: 'status-refuse' },
};

export default function Conge() {
  const { conges, addConge, addFlash } = useApp();
  const router = useRouter();

  const [showForm, setShowForm] = useState(false);
  const [typeConge, setTypeConge] = useState('Congé annuel');
  const [dateDebut, setDateDebut] = useState('');
  const [dateFin, setDateFin] = useState('');
  const [motif, setMotif] = useState('');
  const [error, setError] = useState('');

  const isWeekend = (dateStr: string) => {
    const d = new Date(dateStr);
    return d.getDay() === 0 || d.getDay() === 6;
  };

  const calcJours = () => {
    if (!dateDebut || !dateFin) return 0;
    const d1 = new Date(dateDebut);
    const d2 = new Date(dateFin);
    return Math.max(Math.floor((d2.getTime() - d1.getTime()) / 86400000) + 1, 0);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (isWeekend(dateDebut) || isWeekend(dateFin)) {
      setError('Les dates de congé ne peuvent pas tomber un samedi ou un dimanche.');
      return;
    }
    const nbJours = calcJours();
    if (nbJours < 1) {
      setError('La date de fin doit être après la date de début.');
      return;
    }
    addConge({
      userId: 1,
      typeConge,
      dateDebut,
      dateFin,
      nbJours,
      motif,
      statut: 'en_attente',
    });
    addFlash('success', 'Demande de congé envoyée avec succès!');
    setShowForm(false);
    setDateDebut(''); setDateFin(''); setMotif(''); setTypeConge('Congé annuel');
    router.push('/dashboard');
  };

  const stats = {
    enAttente: conges.filter(c => c.statut === 'en_attente').length,
    approuves: conges.filter(c => c.statut === 'approuve').length,
    total: conges.reduce((acc, c) => acc + c.nbJours, 0),
  };

  return (
    <Layout title="Gestion des congés">
      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 16, marginBottom: 24 }}>
        <div className="card" style={{ padding: '20px 22px', display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ width: 44, height: 44, background: '#FFFBEB', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Clock size={20} color="#D97706" />
          </div>
          <div>
            <div style={{ fontSize: 28, fontWeight: 300, color: 'var(--ink)', letterSpacing: '-1px' }}>{stats.enAttente}</div>
            <div style={{ fontSize: 12, color: 'var(--ink-faint)' }}>En attente</div>
          </div>
        </div>
        <div className="card" style={{ padding: '20px 22px', display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ width: 44, height: 44, background: '#ECFDF5', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <CheckCircle size={20} color="#059669" />
          </div>
          <div>
            <div style={{ fontSize: 28, fontWeight: 300, color: 'var(--ink)', letterSpacing: '-1px' }}>{stats.approuves}</div>
            <div style={{ fontSize: 12, color: 'var(--ink-faint)' }}>Approuvés</div>
          </div>
        </div>
        <div className="card" style={{ padding: '20px 22px', display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ width: 44, height: 44, background: '#EFF6FF', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <CalendarOff size={20} color="#2563EB" />
          </div>
          <div>
            <div style={{ fontSize: 28, fontWeight: 300, color: 'var(--ink)', letterSpacing: '-1px' }}>{stats.total}</div>
            <div style={{ fontSize: 12, color: 'var(--ink-faint)' }}>Total jours</div>
          </div>
        </div>
      </div>

      {/* New request button */}
      <div style={{ marginBottom: 20 }}>
        <button
          onClick={() => setShowForm(!showForm)}
          className="btn-primary"
        >
          <Plus size={14} />
          Nouvelle demande de congé
        </button>
      </div>

      {/* Form */}
      {showForm && (
        <div className="card" style={{ marginBottom: 24 }}>
          <h3 style={{ fontSize: 16, fontWeight: 700, margin: '0 0 20px', color: 'var(--ink)' }}>
            🗓️ Nouvelle demande de congé
          </h3>

          {error && (
            <div style={{
              display: 'flex', alignItems: 'center', gap: 8,
              background: '#FEF2F2', border: '1px solid #FECACA',
              borderRadius: 10, padding: '10px 14px', marginBottom: 16,
              color: '#991B1B', fontSize: 13,
            }}>
              <AlertCircle size={15} />
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 16, marginBottom: 16 }}>
              <div>
                <label className="form-label">Type de congé *</label>
                <select value={typeConge} onChange={e => setTypeConge(e.target.value)} required className="form-input">
                  {TYPES_CONGE.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div />
              <div>
                <label className="form-label">Date de début *</label>
                <input
                  type="date" value={dateDebut}
                  onChange={e => { setDateDebut(e.target.value); if (!dateFin) setDateFin(e.target.value); }}
                  required className="form-input"
                />
              </div>
              <div>
                <label className="form-label">Date de fin *</label>
                <input
                  type="date" value={dateFin} min={dateDebut}
                  onChange={e => setDateFin(e.target.value)}
                  required className="form-input"
                />
              </div>
            </div>

            {dateDebut && dateFin && calcJours() > 0 && (
              <div style={{
                display: 'inline-flex', alignItems: 'center', gap: 6,
                background: '#EFF6FF', border: '1px solid #BFDBFE',
                borderRadius: 8, padding: '8px 14px', marginBottom: 16,
                color: '#1E40AF', fontSize: 13, fontWeight: 500,
              }}>
                📅 {calcJours()} jour(s) de congé
              </div>
            )}

            <div style={{ marginBottom: 16 }}>
              <label className="form-label">Motif (optionnel)</label>
              <textarea
                value={motif} onChange={e => setMotif(e.target.value)}
                placeholder="Précisez le motif de votre demande..."
                rows={3} className="form-input" style={{ resize: 'vertical' }}
              />
            </div>

            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button type="button" onClick={() => setShowForm(false)} className="btn-secondary">
                Annuler
              </button>
              <button type="submit" className="btn-primary">
                Envoyer la demande
              </button>
            </div>
          </form>
        </div>
      )}

      {/* List */}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border)' }}>
          <h3 style={{ margin: 0, fontSize: 15, fontWeight: 600, color: 'var(--ink)' }}>
            Mes demandes de congé
          </h3>
        </div>

        {conges.length === 0 ? (
          <div style={{ padding: 48, textAlign: 'center', color: 'var(--ink-faint)', fontSize: 13 }}>
            <div style={{ fontSize: 32, marginBottom: 8 }}>🏖️</div>
            Aucune demande pour le moment.
          </div>
        ) : (
          <div>
            {conges.map(c => {
              const st = STATUT_LABEL[c.statut] || { label: c.statut, icon: '?', cls: '' };
              return (
                <div key={c.id} style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  padding: '16px 20px', borderBottom: '1px solid var(--border)',
                  flexWrap: 'wrap', gap: 12,
                }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14 }}>
                    <div style={{
                      width: 40, height: 40, borderRadius: 10,
                      background: c.statut === 'approuve' ? '#ECFDF5' : c.statut === 'refuse' ? '#FEF2F2' : '#FFFBEB',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      flexShrink: 0,
                    }}>
                      {c.statut === 'approuve' ? <CheckCircle size={20} color="#059669" /> : c.statut === 'refuse' ? <XCircle size={20} color="#DC2626" /> : <Clock size={20} color="#D97706" />}
                    </div>
                    <div>
                      <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ink)', marginBottom: 3 }}>
                        {c.typeConge}
                      </div>
                      <div style={{ fontSize: 12, color: 'var(--ink-soft)', marginBottom: 4 }}>
                        {format(parseISO(c.dateDebut), 'dd/MM/yyyy')} → {format(parseISO(c.dateFin), 'dd/MM/yyyy')}
                        <span style={{ marginLeft: 8, fontWeight: 600, color: 'var(--ink)' }}>· {c.nbJours} jour(s)</span>
                      </div>
                      {c.motif && (
                        <div style={{ fontSize: 12, color: 'var(--ink-faint)' }}>
                          📝 {c.motif.length > 50 ? c.motif.slice(0, 50) + '...' : c.motif}
                        </div>
                      )}
                      <div style={{ fontSize: 11, color: 'var(--ink-faint)', marginTop: 4 }}>
                        📅 Demandé le {format(parseISO(c.createdAt), 'dd/MM/yyyy')}
                      </div>
                    </div>
                  </div>
                  <span className={`badge ${st.cls}`} style={{ whiteSpace: 'nowrap', padding: '5px 12px' }}>
                    {st.icon} {st.label}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </Layout>
  );
}
