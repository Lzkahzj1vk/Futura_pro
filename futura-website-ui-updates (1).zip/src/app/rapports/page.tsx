'use client';

import { useState, useMemo } from 'react';
import { FileText, Download, Clock } from 'lucide-react';
import Layout from '../../components/Layout';
import { useApp } from '../../context/AppContext';
import { BADGE_MAP } from '../../data/mockData';
import { format } from 'date-fns';

const STATUT_LABEL: Record<string, string> = {
  en_attente: 'En attente', valide: 'Validé', rejete: 'Rejeté', approuve: 'Approuvé', refuse: 'Refusé',
};

export default function Rapports() {
  const { saisies, projets } = useApp();

  // Filters state — Projet EN PREMIER, Type EN DEUXIÈME
  const [filterProjet, setFilterProjet] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterDateDebut, setFilterDateDebut] = useState('');
  const [filterDateFin, setFilterDateFin] = useState('');

  const filteredSaisies = useMemo(() => {
    return saisies.filter(s => {
      if (filterProjet && s.projetId?.toString() !== filterProjet) return false;
      if (filterType && s.typeActivite !== filterType) return false;
      if (filterDateDebut && s.date < filterDateDebut) return false;
      if (filterDateFin && s.date > filterDateFin) return false;
      return true;
    });
  }, [saisies, filterProjet, filterType, filterDateDebut, filterDateFin]);

  const totalHeures = filteredSaisies.reduce((acc, s) => acc + s.heures, 0);

  const getProjetDisplay = (projetId: number | null) => {
    if (!projetId) return 'Interne';
    const p = projets.find(x => x.id === projetId);
    if (!p) return 'Interne';
    return p.client ? `${p.client} — ${p.nom}` : p.nom;
  };

  // Export CSV des saisies filtrées uniquement
  const exportSaisiesCSV = () => {
    let csv = '\uFEFF';
    csv += 'Date;Type;Projet;Heures;Commentaire;Statut\n';
    filteredSaisies.forEach(s => {
      csv += `${s.date};${s.typeActivite};${getProjetDisplay(s.projetId)};${s.heures};${s.commentaire || ''};${STATUT_LABEL[s.statut] || s.statut}\n`;
    });
    csv += `;;;Total: ${totalHeures}h;;\n`;
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rapport_saisies_${format(new Date(), 'yyyyMMdd')}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const uniqueTypes = [...new Set(saisies.map(s => s.typeActivite))].sort();
  const activeProjets = projets.filter(p => p.statut === 'actif');

  return (
    <Layout title="Rapports & Analyses">

      {/* ① Export button — saisies seulement */}
      <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginBottom: 20 }}>
        <button onClick={exportSaisiesCSV} className="btn-primary">
          <Download size={13} /> Exporter saisies CSV
        </button>
      </div>

      {/* ② Filtres — Projet EN PREMIER, Type EN DEUXIÈME */}
      <div className="card" style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ink)', marginBottom: 12 }}>Filtres</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, alignItems: 'flex-end' }}>

          {/* Projet — 1er */}
          <div style={{ flex: '1 1 160px' }}>
            <label className="form-label">Projet</label>
            <select value={filterProjet} onChange={e => setFilterProjet(e.target.value)} className="form-input">
              <option value="">Tous</option>
              {activeProjets.map(p => (
                <option key={p.id} value={p.id.toString()}>
                  {p.client ? `${p.client} — ${p.nom}` : p.nom}
                </option>
              ))}
            </select>
          </div>

          {/* Type — 2ème */}
          <div style={{ flex: '1 1 160px' }}>
            <label className="form-label">Type d&apos;activité</label>
            <select value={filterType} onChange={e => setFilterType(e.target.value)} className="form-input">
              <option value="">Tous</option>
              {uniqueTypes.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>

          <div style={{ flex: '1 1 140px' }}>
            <label className="form-label">Début</label>
            <input type="date" value={filterDateDebut} onChange={e => setFilterDateDebut(e.target.value)} className="form-input" />
          </div>
          <div style={{ flex: '1 1 140px' }}>
            <label className="form-label">Fin</label>
            <input type="date" value={filterDateFin} onChange={e => setFilterDateFin(e.target.value)} className="form-input" />
          </div>
          <button
            onClick={() => { setFilterProjet(''); setFilterType(''); setFilterDateDebut(''); setFilterDateFin(''); }}
            className="btn-secondary" style={{ padding: '9px 14px' }}
          >
            Réinitialiser
          </button>
        </div>
      </div>

      {/* ③ Shariit al-hasila — barre de résumé des heures */}
      <div style={{ display: 'flex', gap: 16, marginBottom: 24, flexWrap: 'wrap' }}>
        <div className="card" style={{ padding: '16px 22px', display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ width: 44, height: 44, background: '#EFF6FF', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Clock size={20} color="#2563EB" />
          </div>
          <div>
            <div style={{ fontSize: 32, fontWeight: 300, color: '#2563EB', letterSpacing: '-1px' }}>{totalHeures}h</div>
            <div style={{ fontSize: 12, color: 'var(--ink-faint)', marginTop: 2 }}>
              Total heures ({filteredSaisies.length} saisie{filteredSaisies.length > 1 ? 's' : ''})
            </div>
          </div>
        </div>

        <div className="card" style={{ padding: '16px 22px', display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ width: 44, height: 44, background: '#F5F3FF', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <FileText size={20} color="#7C3AED" />
          </div>
          <div>
            <div style={{ fontSize: 32, fontWeight: 300, color: '#7C3AED', letterSpacing: '-1px' }}>{filteredSaisies.length}</div>
            <div style={{ fontSize: 12, color: 'var(--ink-faint)', marginTop: 2 }}>Saisies filtrées</div>
          </div>
        </div>

        {/* Heures moyennes par saisie */}
        {filteredSaisies.length > 0 && (
          <div className="card" style={{ padding: '16px 22px', display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{ width: 44, height: 44, background: '#ECFDF5', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Clock size={20} color="#059669" />
            </div>
            <div>
              <div style={{ fontSize: 32, fontWeight: 300, color: '#059669', letterSpacing: '-1px' }}>
                {(totalHeures / filteredSaisies.length).toFixed(1)}h
              </div>
              <div style={{ fontSize: 12, color: 'var(--ink-faint)', marginTop: 2 }}>Moyenne / saisie</div>
            </div>
          </div>
        )}
      </div>

      {/* ④ Tableau des saisies */}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: 8 }}>
          <FileText size={14} color="var(--accent)" />
          <span style={{ fontSize: 14, fontWeight: 600 }}>Historique des saisies</span>
          <span style={{ marginLeft: 'auto', fontSize: 12, color: 'var(--ink-faint)' }}>{filteredSaisies.length} entrée(s)</span>
        </div>
        <div style={{ overflowX: 'auto', maxHeight: 480, overflowY: 'auto' }}>
          <table className="data-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Projet</th>
                <th>Type</th>
                <th>Heures</th>
                <th>Commentaire</th>
                <th>Statut</th>
              </tr>
            </thead>
            <tbody>
              {filteredSaisies.length === 0 ? (
                <tr>
                  <td colSpan={6} style={{ textAlign: 'center', padding: 48, color: 'var(--ink-faint)', fontSize: 13 }}>
                    <div style={{ marginBottom: 8, fontSize: 28 }}>📋</div>
                    Aucune saisie trouvée
                  </td>
                </tr>
              ) : filteredSaisies.map(s => (
                <tr key={s.id}>
                  <td style={{ fontSize: 12, whiteSpace: 'nowrap' }}>{s.date}</td>
                  <td style={{ fontSize: 12, maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {getProjetDisplay(s.projetId)}
                  </td>
                  <td>
                    <span className={`badge ${BADGE_MAP[s.typeActivite] || 'badge-gray'}`} style={{ fontSize: 10 }}>
                      {s.typeActivite.length > 18 ? s.typeActivite.slice(0, 18) + '…' : s.typeActivite}
                    </span>
                  </td>
                  <td style={{ fontWeight: 600, fontSize: 13 }}>{s.heures}h</td>
                  <td style={{ fontSize: 12, color: 'var(--ink-soft)', maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {s.commentaire || '—'}
                  </td>
                  <td>
                    <span className={`badge status-${s.statut}`} style={{ fontSize: 10 }}>
                      {STATUT_LABEL[s.statut] || s.statut}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
            {filteredSaisies.length > 0 && (
              <tfoot>
                <tr style={{ background: 'var(--cream)' }}>
                  <td colSpan={3} style={{ textAlign: 'right', fontWeight: 600, fontSize: 12 }}>TOTAL</td>
                  <td style={{ fontWeight: 700 }}>{totalHeures}h</td>
                  <td colSpan={2} />
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>
    </Layout>
  );
}
