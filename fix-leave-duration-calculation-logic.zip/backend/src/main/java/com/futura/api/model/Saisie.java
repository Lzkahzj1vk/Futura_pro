package com.futura.api.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "saisies")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Saisie {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "projet_id")
    private Projet projet;

    @NotNull
    @Column(nullable = false)
    private LocalDate date;

    @NotBlank
    @Column(name = "type_activite", nullable = false)
    private String typeActivite;

    @NotNull
    @Positive
    @Column(nullable = false)
    private Double heures;

    @Column(columnDefinition = "TEXT")
    private String commentaire;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private Statut statut = Statut.EN_ATTENTE;

    // For multi-day leave
    @Column(name = "conge_date_debut")
    private LocalDate congeDateDebut;

    @Column(name = "conge_date_fin")
    private LocalDate congeDateFin;

    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    public enum Statut {
        EN_ATTENTE, VALIDE, REJETE, APPROUVE, REFUSE
    }
}
