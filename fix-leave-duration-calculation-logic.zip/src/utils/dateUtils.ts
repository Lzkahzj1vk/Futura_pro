/**
 * Check if a date string falls on a weekend (Saturday or Sunday)
 */
export function isWeekend(dateStr: string): boolean {
  const d = new Date(dateStr + 'T12:00:00'); // Noon to avoid timezone issues
  const day = d.getDay();
  return day === 0 || day === 6; // 0 = Sunday, 6 = Saturday
}

/**
 * Calculate the number of working days (Mon–Fri) between two dates (inclusive)
 * Excludes Saturday (6) and Sunday (0)
 * Example: Thursday to Monday = 3 working days (Thu, Fri, Mon)
 */
export function calcJoursOuvrables(dateDebut: string, dateFin: string): number {
  if (!dateDebut || !dateFin) return 0;
  const d1 = new Date(dateDebut + 'T12:00:00');
  const d2 = new Date(dateFin + 'T12:00:00');
  if (d2 < d1) return 0;

  let count = 0;
  const current = new Date(d1);
  while (current <= d2) {
    const day = current.getDay();
    if (day !== 0 && day !== 6) {
      count++;
    }
    current.setDate(current.getDate() + 1);
  }
  return count;
}

/**
 * Get the day name in French for a date string
 */
export function getDayNameFr(dateStr: string): string {
  const d = new Date(dateStr + 'T12:00:00');
  const days = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
  return days[d.getDay()];
}
