import { useApp } from '../context/AppContext';
import { CheckCircle, AlertCircle, Info, X } from 'lucide-react';

export default function FlashMessage() {
  const { flashMessages, clearFlash } = useApp();

  if (flashMessages.length === 0) return null;

  const msg = flashMessages[0];
  const isSuccess = msg.type === 'success';
  const isError = msg.type === 'error';

  const Icon = isSuccess ? CheckCircle : isError ? AlertCircle : Info;
  const cls = isSuccess ? 'flash-success' : isError ? 'flash-error' : 'flash-info';

  return (
    <div style={{ padding: '12px 24px 0' }}>
      <div className={cls} style={{
        display: 'flex', alignItems: 'center', gap: 10,
        padding: '12px 16px', borderRadius: 10, fontSize: 13, fontWeight: 500,
      }}>
        <Icon size={16} style={{ flexShrink: 0 }} />
        <span style={{ flex: 1 }}>{msg.message}</span>
        <button
          onClick={clearFlash}
          style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}
        >
          <X size={14} />
        </button>
      </div>
    </div>
  );
}
