package com.futura.api.repository;

import com.futura.api.model.Projet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProjetRepository extends JpaRepository<Projet, Long> {
    List<Projet> findByStatut(Projet.Statut statut);
    List<Projet> findByStatutOrderByNomAsc(Projet.Statut statut);
}
